import java.awt.Color;
import java.util.Scanner;

public class Processor {
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String input = "";
		int scaleFactor = 1;
		ImageUtils image = new ImageUtils();
		// Load in image
		Color[][] original = image.loadImage("src/LennaCV.png");
		
		System.out.println("Is your screen resolution 4K or higher?"
				+ "\n[1] Yes"
				+ "\n[2] No");
		input = in.next();
		
		if (Integer.parseInt(input) == 1) {
			System.out.println("\nOkay, adjusting the picture for you...");
			scaleFactor = 4;
		} else {
			System.out.println("\nOkay, displaying the picture for you...");
			// scaleFactor is not adjusted
		}
		
		// Add original image tab to window
		image.addImage(original, "Original", scaleFactor);
		
		// Add an image of inverted color
		Color[][] inverted = invert(original);
		image.addImage(inverted, "Inverted", scaleFactor);
		
		// It's okay to be gay in <current year>
		Color[][] lgbt = lgbt(original);
		image.addImage(lgbt, "LGBT in <current year", scaleFactor);
		
		// Flip the image horizontally
		Color[][] hFlip = hFlip(original);
		image.addImage(hFlip, "Horizontal Flip", scaleFactor);
		
		// Flip the image vertically
		Color[][] vFlip = vFlip(original);
		image.addImage(vFlip, "Vertical Flip", scaleFactor);
		
		// Display image in window
		image.display();
	}
	
	// Invert the colors of the image
	public static Color[][] invert(Color[][] image) {
		Color[][] temp = ImageUtils.cloneArray(image);
		
		for (int c = 0; c < temp.length; c++) {
			for (int r = 0; r < temp[c].length; r++) {
				Color pixel = temp[c][r];
				int red = pixel.getRed();
				int green = pixel.getGreen();
				int blue = pixel.getBlue();
				temp[c][r] = new Color((255 - red), (255 - green), (255 - blue));
			}
		}
		
		return temp;
	}
	
	// Add a slightly transparent LGBT flag over the image, because it's <current year>.
	public static Color[][] lgbt(Color[][] image) {
		Color[][] temp = ImageUtils.cloneArray(image);
		
		for (int c = 0; c < temp.length; c++) {
			if (c <= (temp.length/5)) {
				for (int r = 0; r < temp[c].length; r++) {
					Color pixel = temp[c][r];
					int red = pixel.getRed();
					int green = pixel.getGreen();
					int blue = pixel.getBlue();
					temp[c][r] = new Color((red + 212)/2, (green + 6)/2, (blue + 6)/2);
				}
			} else if (c > (temp.length/5) && c <= (2 * temp.length)/5) {
				for (int r = 0; r < temp[c].length; r++) {
					Color pixel = temp[c][r];
					int red = pixel.getRed();
					int green = pixel.getGreen();
					int blue = pixel.getBlue();
					temp[c][r] = new Color((red + 238)/2, (green + 156)/2, (blue + 0)/2);
				}
			} else if (c > (2 * temp.length)/5 && c <= (3 * temp.length)/5) {
				for (int r = 0; r < temp[c].length; r++) {
					Color pixel = temp[c][r];
					int red = pixel.getRed();
					int green = pixel.getGreen();
					int blue = pixel.getBlue();
					temp[c][r] = new Color((red + 227)/2, (green + 255)/2, (blue + 0)/2);
				}
			} else if (c > (3 * temp.length)/5 && c <= (4 * temp.length)/5) {
				for (int r = 0; r < temp[c].length; r++) {
					Color pixel = temp[c][r];
					int red = pixel.getRed();
					int green = pixel.getGreen();
					int blue = pixel.getBlue();
					temp[c][r] = new Color((red + 6)/2, (green + 191)/2, (blue + 0)/2);
				}
			} else {
				for (int r = 0; r < temp[c].length; r++) {
					Color pixel = temp[c][r];
					int red = pixel.getRed();
					int green = pixel.getGreen();
					int blue = pixel.getBlue();
					temp[c][r] = new Color((red + 0)/2, (green + 26)/2, (blue + 152)/2);
				}
			}
			
		}
		
		return temp;
	}
	
	// Flip the image horizontally
	public static Color[][] hFlip(Color[][] image) {
		Color [][] temp = ImageUtils.cloneArray(image);
		Color [][] flipped = new Color[temp.length][temp[0].length];
		
		for (int c = 0; c < temp.length; c++) {
			for (int r = 0; r < temp[c].length; r++) {
				flipped[c][r] = temp[c][(temp[c].length - 1) - r];
			}
		}
		
		return flipped;
		
	}
	
	// Flip the image vertically
	public static Color[][] vFlip(Color[][] image) {
		Color[][] temp = ImageUtils.cloneArray(image);
		Color[][] flipped = new Color[temp.length][temp[0].length];
		
		for (int c = 0; c < temp.length; c++) {
			for (int r = 0; r < temp[c].length; r++) {
				flipped[c][r] = temp[(temp.length - 1) - c][r];
			}
		}
		
		return flipped;
	}
	
}
